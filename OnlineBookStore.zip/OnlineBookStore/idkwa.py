# a=int(input('enter a number'))
# b = int(input('enter a number again'))
# m = max(a,b)
# n= min(a,b)
# print ('max number is' + str(m))
# print('min number is' +str(n))

i=0
while i<=20:
    print(i*"*")
    i=i+1